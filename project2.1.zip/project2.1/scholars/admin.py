from django.contrib import admin
from scholars.models import Scholar


@admin.register(Scholar)
class BookModelAdmin(admin.ModelAdmin):
    list_display = ['name', 'birth']
    search_fields = ['name']
