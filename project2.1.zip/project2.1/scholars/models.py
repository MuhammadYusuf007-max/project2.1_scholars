from django.db import models


class Scholar(models.Model):

    name = models.CharField(max_length=128)
    birth = models.IntegerField()
    info = models.TextField()
    books = models.TextField()
    image = models.ImageField(upload_to='media/', null=True)

    def __str__(self):
        return self.name
