from django.urls import path

from scholars.views import scholar_list_view, scholar_detail_view, download_img_view

app_name = 'scholars'

urlpatterns = [
    path('', scholar_list_view, name='list'),
    path('<int:pk>/', scholar_detail_view, name='detail'),
]