from django.http import HttpResponse
from django.shortcuts import render

from scholars.models import Scholar


def scholar_list_view(request):
    scholars = Scholar.objects.all()
    q = request.GET.get('q')
    if q:
        scholars = scholars.filter(name__contains=q)
    context = {'scholars': scholars}
    return render(request, template_name='scholar.html', context=context)


def scholar_detail_view(request, pk):
    scholar = Scholar.objects.filter(id=pk).first()
    if scholar:
        context = {'scholar': scholar}
        return render(request, template_name='scholar_detail.html', context=context)
    else:
        return HttpResponse('Book not found')


def download_img_view(request, pk):
    scholar = Scholar.objects.filter(id=pk).first()
    if scholar:
        file_path = str(scholar.image)
        with open('', 'rb') as f:
            response = HttpResponse(f.read(), content_type='application/jpeg')
            return response

    else:
        return HttpResponse("Scholar's photo not found")
